Uploaded images are stored here. Files are served only via /i/:id.
